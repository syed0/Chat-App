package com.android.tools.p000ir.runtime;

/* renamed from: com.android.tools.ir.runtime.InstantReloadException */
public class InstantReloadException extends Exception {
    public InstantReloadException(String s) {
        super(s);
    }
}
