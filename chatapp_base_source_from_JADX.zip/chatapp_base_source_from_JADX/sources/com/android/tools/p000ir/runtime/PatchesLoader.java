package com.android.tools.p000ir.runtime;

/* renamed from: com.android.tools.ir.runtime.PatchesLoader */
public interface PatchesLoader {
    boolean load();
}
