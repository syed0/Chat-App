package com.android.tools.p000ir.server;

/* renamed from: com.android.tools.ir.server.AppInfo */
public class AppInfo {
    public static String applicationId = "com.example.chatapp.chatapp";
    public static long token = -7302616767071188258L;
}
